# ngFoodie
Starter files for Angular Project
