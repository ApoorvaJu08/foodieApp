window.onload = function() {

	// Write AJAX call here 
	
}